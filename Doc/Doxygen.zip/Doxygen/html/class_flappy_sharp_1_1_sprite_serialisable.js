var class_flappy_sharp_1_1_sprite_serialisable =
[
    [ "SpriteSerialisable", "class_flappy_sharp_1_1_sprite_serialisable.html#a022362f9767d86a21f15903f7f7f1fca", null ],
    [ "SetValue", "class_flappy_sharp_1_1_sprite_serialisable.html#a52b7c84b06365b7c2968974f8be7f54e", null ],
    [ "AngleRotation", "class_flappy_sharp_1_1_sprite_serialisable.html#ab7712dc4b99986e3ccc7a429262e2722", null ],
    [ "Calque", "class_flappy_sharp_1_1_sprite_serialisable.html#a75c7881c083d417aece8e84ade64ecfb", null ],
    [ "CheminDossier", "class_flappy_sharp_1_1_sprite_serialisable.html#acd27ac74751d6edec7a043d4b1caf77e", null ],
    [ "IntervalEntreImage", "class_flappy_sharp_1_1_sprite_serialisable.html#a01dc6b0f66fceb8a0931e8d6763cf78a", null ],
    [ "Nom", "class_flappy_sharp_1_1_sprite_serialisable.html#ae539f46af4887011cf88608e83f30384", null ],
    [ "NomImages", "class_flappy_sharp_1_1_sprite_serialisable.html#adec9a7c2030648d49c3a20ab69385b36", null ],
    [ "Position", "class_flappy_sharp_1_1_sprite_serialisable.html#a4d4e5b82a2bee7bdbad0c214d409da1d", null ],
    [ "TagSprite", "class_flappy_sharp_1_1_sprite_serialisable.html#a50e2cc7d56b81c61e1be5e49e368d395", null ],
    [ "Taille", "class_flappy_sharp_1_1_sprite_serialisable.html#a502546304e317df2c44f83815bb1476f", null ],
    [ "ZOrder", "class_flappy_sharp_1_1_sprite_serialisable.html#a5b5fc7cd74b8e4bb4d3c618e6849bfbf", null ]
];