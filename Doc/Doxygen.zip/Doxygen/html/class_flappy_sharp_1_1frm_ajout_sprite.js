var class_flappy_sharp_1_1frm_ajout_sprite =
[
    [ "frmAjoutSprite", "class_flappy_sharp_1_1frm_ajout_sprite.html#a867ec290f5d95abb95d6b2cf4969f910", null ],
    [ "Dispose", "class_flappy_sharp_1_1frm_ajout_sprite.html#a36839a88d77064e8c713ba8047d10cdb", null ],
    [ "GetCalque", "class_flappy_sharp_1_1frm_ajout_sprite.html#acd58def7031e49c4f4d6c5879404a539", null ],
    [ "GetImages", "class_flappy_sharp_1_1frm_ajout_sprite.html#a6e951f1e44021c3dcdeab5fa6e0ef619", null ],
    [ "GetNom", "class_flappy_sharp_1_1frm_ajout_sprite.html#a72abf3c6c4db51ef0011fa72fffa90e6", null ],
    [ "GetPosition", "class_flappy_sharp_1_1frm_ajout_sprite.html#adaf20a93722fcb6c688a378226789a81", null ],
    [ "GetTaille", "class_flappy_sharp_1_1frm_ajout_sprite.html#a268ecc39af0a476a95676b9118454c3f", null ]
];