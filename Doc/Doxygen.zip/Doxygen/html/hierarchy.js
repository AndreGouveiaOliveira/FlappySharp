var hierarchy =
[
    [ "Form", null, [
      [ "FlappySharp.frmAjoutSprite", "class_flappy_sharp_1_1frm_ajout_sprite.html", null ],
      [ "FlappySharp.frmCreationProjet", "class_flappy_sharp_1_1frm_creation_projet.html", null ],
      [ "FlappySharp.frmMain", "class_flappy_sharp_1_1frm_main.html", null ],
      [ "FlappySharp.frmPlateauJeu", "class_flappy_sharp_1_1frm_plateau_jeu.html", null ]
    ] ],
    [ "FlappySharp.Jeu", "class_flappy_sharp_1_1_jeu.html", null ],
    [ "PictureBox", null, [
      [ "FlappySharp.Sprite", "class_flappy_sharp_1_1_sprite.html", null ]
    ] ],
    [ "FlappySharp.SpriteSerialisable", "class_flappy_sharp_1_1_sprite_serialisable.html", null ]
];