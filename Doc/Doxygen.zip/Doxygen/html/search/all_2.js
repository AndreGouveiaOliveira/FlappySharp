var searchData=
[
  ['demareanimation_15',['DemareAnimation',['../class_flappy_sharp_1_1_sprite.html#a972af58498b8974bde88ec363cee7f2b',1,'FlappySharp::Sprite']]],
  ['deplacement_16',['Deplacement',['../class_flappy_sharp_1_1_sprite.html#ad0847ce1f27367580f520dffce004499',1,'FlappySharp::Sprite']]],
  ['dispose_17',['Dispose',['../class_flappy_sharp_1_1frm_ajout_sprite.html#a36839a88d77064e8c713ba8047d10cdb',1,'FlappySharp.frmAjoutSprite.Dispose()'],['../class_flappy_sharp_1_1frm_creation_projet.html#a30ef8ff40b9d6a1a36a5461983e93cab',1,'FlappySharp.frmCreationProjet.Dispose()'],['../class_flappy_sharp_1_1frm_main.html#afa0d064a7a7b171b68b0f47ce37fd7f9',1,'FlappySharp.frmMain.Dispose()'],['../class_flappy_sharp_1_1frm_plateau_jeu.html#a98e16622021664ca5e9463afc8304d5f',1,'FlappySharp.frmPlateauJeu.Dispose()']]]
];
