var searchData=
[
  ['images_41',['Images',['../class_flappy_sharp_1_1_sprite.html#af2650a285cded50d51896469dc7350ef',1,'FlappySharp::Sprite']]],
  ['intervalentreimage_42',['IntervalEntreImage',['../class_flappy_sharp_1_1_sprite.html#a9a35cd8ee4004c69c51af06b7c3f17aa',1,'FlappySharp.Sprite.IntervalEntreImage()'],['../class_flappy_sharp_1_1_sprite_serialisable.html#a01dc6b0f66fceb8a0931e8d6763cf78a',1,'FlappySharp.SpriteSerialisable.IntervalEntreImage()']]]
];
