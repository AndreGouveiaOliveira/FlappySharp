var searchData=
[
  ['refreshcontrol_51',['RefreshControl',['../class_flappy_sharp_1_1_jeu.html#ac885613b4672b1f2ca2c803992c179b6',1,'FlappySharp::Jeu']]],
  ['resources_2edesigner_2ecs_52',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]]
];
