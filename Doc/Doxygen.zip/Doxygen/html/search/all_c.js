var searchData=
[
  ['tagsprite_62',['TagSprite',['../class_flappy_sharp_1_1_sprite.html#a26446b09abb52389d210529345feade0',1,'FlappySharp.Sprite.TagSprite()'],['../class_flappy_sharp_1_1_sprite_serialisable.html#a50e2cc7d56b81c61e1be5e49e368d395',1,'FlappySharp.SpriteSerialisable.TagSprite()']]],
  ['taille_63',['Taille',['../class_flappy_sharp_1_1_sprite_serialisable.html#a502546304e317df2c44f83815bb1476f',1,'FlappySharp::SpriteSerialisable']]]
];
