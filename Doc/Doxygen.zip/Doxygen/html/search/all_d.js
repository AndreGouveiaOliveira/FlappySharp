var searchData=
[
  ['updatevalue_64',['UpdateValue',['../class_flappy_sharp_1_1_sprite.html#aff7323e469e1f7f9202f810d80e69aa8',1,'FlappySharp::Sprite']]],
  ['updatevaluespriteselected_65',['UpdateValueSpriteSelected',['../class_flappy_sharp_1_1_jeu.html#a474828d23e9084acf33d72dbb36285f5',1,'FlappySharp::Jeu']]]
];
