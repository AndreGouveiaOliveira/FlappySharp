var searchData=
[
  ['xmldeserialize_66',['XMLDeserialize',['../class_flappy_sharp_1_1_jeu.html#aa9226e770a20438797dda8e71a0011df',1,'FlappySharp::Jeu']]],
  ['xmlserialize_67',['XMLSerialize',['../class_flappy_sharp_1_1_jeu.html#a69a84e791d493a22c4a944a9caa815e3',1,'FlappySharp::Jeu']]]
];
