var searchData=
[
  ['assemblyinfo_2ecs_78',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
