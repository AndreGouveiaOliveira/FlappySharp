var searchData=
[
  ['anglerotation_127',['AngleRotation',['../class_flappy_sharp_1_1_sprite.html#acdddca01785bc9d1ce4d45a3463e7df7',1,'FlappySharp.Sprite.AngleRotation()'],['../class_flappy_sharp_1_1_sprite_serialisable.html#ab7712dc4b99986e3ccc7a429262e2722',1,'FlappySharp.SpriteSerialisable.AngleRotation()']]]
];
